#!/usr/bin/env python
"""Boilerplate test Module"""

import unittest


class TestBasicFunction(unittest.TestCase):
    """Boilerplate test class"""
    # def setUp(self):
    #    self.func = BasicFunction()

    def test_1(self):
        """Boilerplate test case"""
        self.assertTrue(True)

    def test_2(self):
        """Boilerplate test case"""
        self.assertTrue(True)


if __name__ == '__main__':
    unittest.main()
