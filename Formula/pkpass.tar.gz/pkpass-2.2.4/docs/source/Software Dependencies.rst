Software Dependencies
=====================
Pkpass has few dependencies. Fernet is a crypto library used to allow automatic symmetric encrypting.  Fernet can be installed using pip:
  ``pip install cryptography``

Other dependencies can be found in requirements.txt  

*Note:* All dependencies will be installed if the setup script is run.
