Windows Consideration
=====================
There has not been much (if any) testing around the windows ecosystem. Coding has been attempted to comply with portability standards;
but compatibility is not guaranteed. If you need it, feel free to submit a PR 😀
